# Merged All Core Ontology

This directory contains a merged version of all eleven CCO ontologies plus BFO. The file represents a stable stand-alone snapshot release of all of CCO and its import dependancies. A sub-directory archives previous versions of Merged All Core.
