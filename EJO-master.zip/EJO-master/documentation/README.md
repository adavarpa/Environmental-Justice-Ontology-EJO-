This folder contains user guides and supporting documents, some of which are specific to the current release. Previous versions of these documents are now stored in the Legacy subfolder.
